---
layout: tag_page
tag: Daniel Kahneman
---
