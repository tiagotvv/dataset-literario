---
layout: tag_page
tag: Nick Bostrom
---
