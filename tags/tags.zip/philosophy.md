---
layout: tag_page
tag: philosophy
---
