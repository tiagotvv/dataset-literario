---
layout: tag_page
tag: Steven H. Strogatz
---
