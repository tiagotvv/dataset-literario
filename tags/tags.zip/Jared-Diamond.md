---
layout: tag_page
tag: Jared Diamond
---
