---
layout: tag_page
tag: Gabriel García Márquez
---
