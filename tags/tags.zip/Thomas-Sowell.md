---
layout: tag_page
tag: Thomas Sowell
---
