---
layout: tag_page
tag: Hans Rosling
---
